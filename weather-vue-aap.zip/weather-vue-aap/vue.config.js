module.exports = {
  publicPath: "/weather-app/",
};
