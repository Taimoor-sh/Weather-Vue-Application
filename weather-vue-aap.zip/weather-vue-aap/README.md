# vue-weather

## uses OpenWeather API to search and display weather from accross the globe
## Demo <a href="https://github.com/Taimoor-sh/Weather-Vue-Application.git" target="_blank">Here</a>

#### by Taimoor Shafiq

## Project setup

```
npm install
```

### Compiles and hot-reloads for development

```
npm run serve
```

### Compiles and minifies for production

```
npm run build
```
